﻿using System;
using TreeAppGym.App.Dominio;
namespace TreeAppGym.App.Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
