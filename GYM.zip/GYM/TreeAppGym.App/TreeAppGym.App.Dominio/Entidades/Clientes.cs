using System;
namespace TreeAppGym.App.Dominio
{
    public class clientes
    {
        public int ID {get;set;}
        public string Nombre {get;set;}
        public string Apellido{get;set;}
        public string Email{get;set;}
        public string Telefono{get;set;}
        public string Direccion {get;set;}
        public string Usuario {get;set;}
        public string Password {get;set;}
        public int Peso {get;set;}
        public string Sexo {get;set;}
        public string Estatura {get;set;}
        public string IMC {get;set;}




    }
}
    









    