using System;

namespace TreeAppGym.App.Dominio
{
    public class Gym 
    {
        public int  IDGym{get;set;}
        public string ID{get;set;}
        public string IDRutinas{get;set;}
        public string IDPlanNutricional{get;set;}
        public string Fecha {get;set;}
        public string Estado {get;set;}

    }
}