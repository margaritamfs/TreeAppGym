using System;

namespace TreeAppGym.App.Dominio
{
    public class PlanNutricional
    {
        public string IDPlanNutricional {get;set;}
        public string Texto {get;set;}
        public string Imagen {get;set;}
        public string Categoria {get;set;}
        

    }
}