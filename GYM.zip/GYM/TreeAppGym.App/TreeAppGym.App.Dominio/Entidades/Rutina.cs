using System;

namespace TreeAppGym.App.Dominio
{
    public class Rutinas
    {
        public string IdRutinas {get;set;}
        public string Texto{get;set;}
        public string Imagen{get;set;}
        public string Video{get;set;}
        public string Categoria{get;set;}
        

    }
}