namespace TreeAppGym.App.Dominio
{
    public enum Categoria
    {
        basica,
        intermedia,
        avanzada
    }

}