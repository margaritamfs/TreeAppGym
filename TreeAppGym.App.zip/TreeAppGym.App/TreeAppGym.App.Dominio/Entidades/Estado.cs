namespace TreeAppGym.App.Dominio
{
    public enum Estado
    {
        logrado,
        noLogrado
    }

}