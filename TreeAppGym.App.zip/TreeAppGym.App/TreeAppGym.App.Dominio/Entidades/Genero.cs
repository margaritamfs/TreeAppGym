namespace TreeAppGym.App.Dominio
{
    public enum Genero
    {
        masculino,
        femenino
    }

}
