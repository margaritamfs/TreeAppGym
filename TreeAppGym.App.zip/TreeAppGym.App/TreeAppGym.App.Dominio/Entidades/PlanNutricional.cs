using System;

namespace TreeAppGym.App.Dominio
{
    public class PlanNutricional
    {
    public int Id {get; set;}
    public Categoria Categoria {get; set;}
    public string Descripcion {get; set;}
    public string Imagen { get; set; }       
    }

}
