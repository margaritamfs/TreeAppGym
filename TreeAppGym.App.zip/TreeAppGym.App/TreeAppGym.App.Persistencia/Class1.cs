﻿using System;

namespace TreeAppGym.App.Persistencia
{
    public class Class1
    {
    }
}
