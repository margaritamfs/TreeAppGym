﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TreeAppGym.App.Persistencia.Migrations
{
    public partial class Otro : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
